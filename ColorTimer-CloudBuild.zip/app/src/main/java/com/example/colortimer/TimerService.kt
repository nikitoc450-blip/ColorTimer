package com.example.colortimer

import android.app.*
import android.content.*
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.*
import android.widget.FrameLayout

class TimerService : Service() {
    companion object {
        const val PREFS = "color_timer"
        const val ACTION_START = "com.example.colortimer.START"
        private const val CHANNEL = "color_timer_silent"
        private const val NOTIFICATION_ID = 7
    }

    private val handler = Handler(Looper.getMainLooper())
    private var windowManager: WindowManager? = null
    private var indicator: View? = null
    private var deadline = 0L
    private var wakeLock: PowerManager.WakeLock? = null
    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }

    private val tick = object : Runnable {
        override fun run() {
            val remaining = deadline - SystemClock.elapsedRealtime()
            if (remaining <= 0L) {
                prefs.edit().putBoolean("finished", true).apply()
                paint(true)
            } else {
                paint(false)
                handler.postDelayed(this, minOf(remaining, 500L))
                return
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        acquireWakeLock()
        showOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START || !prefs.getBoolean("running", false)) {
            val duration = prefs.getInt("duration", 300).coerceAtLeast(10)
            deadline = SystemClock.elapsedRealtime() + duration * 1000L
            prefs.edit().putLong("deadline", deadline).putBoolean("running", true)
                .putBoolean("finished", false).apply()
        } else {
            deadline = prefs.getLong("deadline", SystemClock.elapsedRealtime())
        }
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("ColorTimer")
                .setContentText("Визуальный таймер работает")
                .setOngoing(true)
                .setSilent(true)
                .setOnlyAlertOnce(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("ColorTimer")
                .setContentText("Визуальный таймер работает")
                .setOngoing(true)
                .build()
        }
        startForeground(NOTIFICATION_ID, notification)
        showOverlay()
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Таймер (без звука)", NotificationManager.IMPORTANCE_LOW)
            channel.setSound(null, null)
            channel.enableVibration(false)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ColorTimer:Timer")
        wakeLock?.setReferenceCounted(false)
        wakeLock?.acquire(26 * 60 * 60 * 1000L)
    }

    private fun showOverlay() {
        if (indicator != null || !android.provider.Settings.canDrawOverlays(this)) return
        val dot = View(this).apply {
            background = circle(0xFF31B66A.toInt())
            setOnClickListener { restartTimer() }
        }
        indicator = dot
        val params = WindowManager.LayoutParams(
            dp(54), dp(54),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(18); y = dp(150)
        }
        try { windowManager?.addView(dot, params) } catch (_: Exception) { indicator = null }
    }

    private fun restartTimer() {
        val duration = prefs.getInt("duration", 300).coerceAtLeast(10)
        deadline = SystemClock.elapsedRealtime() + duration * 1000L
        prefs.edit().putLong("deadline", deadline).putBoolean("running", true)
            .putBoolean("finished", false).apply()
        handler.removeCallbacks(tick)
        paint(false)
        handler.post(tick)
    }

    private fun paint(finished: Boolean) {
        indicator?.background = circle(if (finished) 0xFFE53935.toInt() else 0xFF31B66A.toInt())
    }

    private fun circle(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
        setStroke(dp(2), 0x55FFFFFF)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        try { indicator?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        indicator = null
        prefs.edit().putBoolean("running", false).apply()
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
