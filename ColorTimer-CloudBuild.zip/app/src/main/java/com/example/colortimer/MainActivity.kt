package com.example.colortimer

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import android.os.Handler
import android.os.Looper

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(TimerService.PREFS, MODE_PRIVATE) }
    private lateinit var value: TextView
    private lateinit var status: TextView
    private lateinit var start: Button
    private var seconds = 300
    private val handler = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() {
            seconds = prefs.getInt("duration", seconds)
            value.text = format(seconds)
            val running = prefs.getBoolean("running", false)
            status.text = if (running) {
                if (prefs.getBoolean("finished", false)) "Время вышло — индикатор красный"
                else "Таймер работает в фоне"
            } else "Таймер остановлен"
            start.text = if (running) "Таймер запущен" else "ЗАПУСТИТЬ"
            start.isEnabled = !running
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        seconds = prefs.getInt("duration", 300)
        buildUi()
        handler.post(refresh)
        requestNotificationPermission()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 48, 28, 28)
            setBackgroundColor(Color.rgb(246, 247, 249))
        }
        val title = TextView(this).apply {
            text = "ColorTimer"; textSize = 28f; setTextColor(Color.BLACK)
            gravity = Gravity.CENTER; typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        value = TextView(this).apply {
            textSize = 52f; setTextColor(Color.rgb(30, 35, 40))
            gravity = Gravity.CENTER; typeface = android.graphics.Typeface.MONOSPACE
            setPadding(0, 40, 0, 12)
        }
        status = TextView(this).apply {
            textSize = 16f; setTextColor(Color.DKGRAY); gravity = Gravity.CENTER
            setPadding(0, 0, 0, 32)
        }
        val minus = Button(this).apply { text = "− 10 сек"; setOnClickListener { change(-10) } }
        val plus = Button(this).apply { text = "+ 10 сек"; setOnClickListener { change(10) } }
        val adjust = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            addView(minus, LinearLayout.LayoutParams(0, -2, 1f))
            addView(plus, LinearLayout.LayoutParams(0, -2, 1f))
        }
        start = Button(this).apply {
            text = "ЗАПУСТИТЬ"; textSize = 16f
            setOnClickListener { startTimer() }
        }
        val stop = Button(this).apply {
            text = "СТОП"; textSize = 16f
            setOnClickListener { stopService(Intent(this@MainActivity, TimerService::class.java)) }
        }
        val note = TextView(this).apply {
            text = "Зелёный индикатор — отсчёт идёт. Красный — время вышло.\nКасание индикатора перезапускает выбранный интервал."
            textSize = 14f; setTextColor(Color.GRAY); gravity = Gravity.CENTER
            setPadding(8, 30, 8, 0)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(value, LinearLayout.LayoutParams(-1, -2))
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(adjust, LinearLayout.LayoutParams(-1, -2))
        root.addView(start, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 22 })
        root.addView(stop, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        root.addView(note, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun change(delta: Int) {
        if (prefs.getBoolean("running", false)) return
        seconds = (seconds + delta).coerceIn(10, 24 * 60 * 60)
        prefs.edit().putInt("duration", seconds).apply()
        value.text = format(seconds)
    }

    private fun startTimer() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
            Toast.makeText(this, "Разреши отображение поверх других приложений, затем нажми «Запустить» ещё раз", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 42)
        }
        val i = Intent(this, TimerService::class.java).apply { action = TimerService.ACTION_START }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 42)
        }
    }

    private fun format(s: Int): String = String.format("%02d:%02d", s / 60, s % 60)

    override fun onDestroy() {
        handler.removeCallbacks(refresh)
        super.onDestroy()
    }
}
